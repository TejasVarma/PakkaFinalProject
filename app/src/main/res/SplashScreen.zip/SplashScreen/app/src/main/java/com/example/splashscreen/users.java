package com.example.splashscreen;

public class users {

    public String Email, Gender;

    public users(){

    }

    public users(String email, String gender) {
        Email = email;
        Gender = gender;
    }
}
